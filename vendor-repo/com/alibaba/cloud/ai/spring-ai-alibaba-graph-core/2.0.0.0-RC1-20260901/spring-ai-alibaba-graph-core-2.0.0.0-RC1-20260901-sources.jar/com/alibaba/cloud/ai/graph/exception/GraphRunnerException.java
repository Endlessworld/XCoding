/*
 * Copyright 2024-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.cloud.ai.graph.exception;

/**
 * Exception thrown when there is an error during the execution of a graph runner.
 */
public class GraphRunnerException extends Exception {

	/**
	 * Constructs a new GraphRunnerException with the specified error message.
	 * @param errorMessage the detail message
	 */
	public GraphRunnerException(String errorMessage) {
		super(errorMessage);
	}

	/**
	 * Constructs a new GraphRunnerException with the specified error message and cause.
	 * @param errorMessage the detail message
	 * @param cause the cause
	 */
	public GraphRunnerException(String errorMessage, Throwable cause) {
		super(errorMessage, cause);
	}

}
